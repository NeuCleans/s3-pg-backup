--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE accounts;
--
-- Name: accounts; Type: DATABASE; Schema: -; Owner: bernard
--

CREATE DATABASE accounts WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE accounts OWNER TO bernard;

\connect accounts

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calendar_availability; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.calendar_availability (
    id integer NOT NULL,
    date date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.calendar_availability OWNER TO bernard;

--
-- Name: calendar_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.calendar_availability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calendar_availability_id_seq OWNER TO bernard;

--
-- Name: calendar_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.calendar_availability_id_seq OWNED BY public.calendar_availability.id;


--
-- Name: cleaner_availability; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.cleaner_availability (
    cleaner_id integer NOT NULL,
    calendar_date_id integer NOT NULL,
    company_availability_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.cleaner_availability OWNER TO bernard;

--
-- Name: cleaning_companies; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.cleaning_companies (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    street_1 character varying(255) NOT NULL,
    street_2 character varying(255),
    city character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    zip character varying(255) NOT NULL,
    country character varying(255) DEFAULT 'united states'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    insured boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cleaning_companies OWNER TO bernard;

--
-- Name: cleaning_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.cleaning_companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cleaning_companies_id_seq OWNER TO bernard;

--
-- Name: cleaning_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.cleaning_companies_id_seq OWNED BY public.cleaning_companies.id;


--
-- Name: company_availability; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.company_availability (
    id integer NOT NULL,
    company_id integer NOT NULL,
    calendar_date_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.company_availability OWNER TO bernard;

--
-- Name: company_availability_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.company_availability_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.company_availability_id_seq OWNER TO bernard;

--
-- Name: company_availability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.company_availability_id_seq OWNED BY public.company_availability.id;


--
-- Name: join_cleaning_companies_cleaners; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.join_cleaning_companies_cleaners (
    cleaner_id integer,
    cleaning_company_id integer,
    is_company_admin boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.join_cleaning_companies_cleaners OWNER TO bernard;

--
-- Name: join_host_properties; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.join_host_properties (
    host_id integer,
    property_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.join_host_properties OWNER TO bernard;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migrations OWNER TO bernard;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO bernard;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: migrations_lock; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.migrations_lock (
    is_locked integer
);


ALTER TABLE public.migrations_lock OWNER TO bernard;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    notes text,
    ref text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    title character varying(255),
    photos jsonb DEFAULT '[]'::jsonb,
    amenities jsonb DEFAULT '[]'::jsonb,
    address jsonb DEFAULT '{"zip": null, "city": null, "state": null, "country": "United States", "street1": null, "street2": null}'::jsonb NOT NULL,
    room_details jsonb DEFAULT '{"bedrooms": {"king": 0, "twin": 0, "queen": 0, "double": 0, "bedCount": 0, "roomCount": 0}, "roomType": "Entire home/apt", "bathrooms": 0, "accommodates": 0}'::jsonb NOT NULL,
    ref_ids jsonb DEFAULT '{"airbnb": {"id": null, "ical": null}}'::jsonb,
    primary_host integer NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    active_plan character varying(255),
    pricing_plans jsonb DEFAULT '{"ultra": {"price": 0, "firstClean": 0}, "simple": {"price": 0, "firstClean": 0}, "essential": {"price": 0, "firstClean": 0}}'::jsonb NOT NULL,
    property_details jsonb DEFAULT '{"keys": false, "parking": false, "numOfTubs": 0, "numOfStairs": 0, "propertyType": "House", "numOf3qtBaths": 0, "numOfKitchens": 1, "numOfSpareSets": 1}'::jsonb NOT NULL,
    check_in_out jsonb DEFAULT '{"in": null, "out": null}'::jsonb,
    instructions jsonb DEFAULT '{"trash": "", "access": "", "parking": ""}'::jsonb NOT NULL
);


ALTER TABLE public.properties OWNER TO bernard;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.properties_id_seq OWNER TO bernard;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: bernard
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    phone character varying(255),
    address character varying(255),
    city character varying(255),
    state character varying(255),
    country character varying(255) DEFAULT 'united states'::character varying,
    zip character varying(255),
    image_url character varying(255),
    rbac jsonb NOT NULL,
    hash character varying(255),
    is_active boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO bernard;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: bernard
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO bernard;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bernard
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: calendar_availability id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.calendar_availability ALTER COLUMN id SET DEFAULT nextval('public.calendar_availability_id_seq'::regclass);


--
-- Name: cleaning_companies id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaning_companies ALTER COLUMN id SET DEFAULT nextval('public.cleaning_companies_id_seq'::regclass);


--
-- Name: company_availability id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.company_availability ALTER COLUMN id SET DEFAULT nextval('public.company_availability_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: calendar_availability; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.calendar_availability (id, date, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.calendar_availability (id, date, created_at, updated_at, deleted_at) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: cleaner_availability; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.cleaner_availability (cleaner_id, calendar_date_id, company_availability_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.cleaner_availability (cleaner_id, calendar_date_id, company_availability_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: cleaning_companies; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.cleaning_companies (id, name, street_1, street_2, city, state, zip, country, created_at, updated_at, deleted_at, insured) FROM stdin;
\.
COPY public.cleaning_companies (id, name, street_1, street_2, city, state, zip, country, created_at, updated_at, deleted_at, insured) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: company_availability; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.company_availability (id, company_id, calendar_date_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.company_availability (id, company_id, calendar_date_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: join_cleaning_companies_cleaners; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.join_cleaning_companies_cleaners (cleaner_id, cleaning_company_id, is_company_admin, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.join_cleaning_companies_cleaners (cleaner_id, cleaning_company_id, is_company_admin, created_at, updated_at, deleted_at) FROM '$$PATH$$/3313.dat';

--
-- Data for Name: join_host_properties; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.join_host_properties (host_id, property_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.join_host_properties (host_id, property_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.migrations (id, name, batch, migration_time) FROM stdin;
\.
COPY public.migrations (id, name, batch, migration_time) FROM '$$PATH$$/3304.dat';

--
-- Data for Name: migrations_lock; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.migrations_lock (is_locked) FROM stdin;
\.
COPY public.migrations_lock (is_locked) FROM '$$PATH$$/3305.dat';

--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.properties (id, notes, ref, created_at, updated_at, deleted_at, title, photos, amenities, address, room_details, ref_ids, primary_host, is_active, active_plan, pricing_plans, property_details, check_in_out, instructions) FROM stdin;
\.
COPY public.properties (id, notes, ref, created_at, updated_at, deleted_at, title, photos, amenities, address, room_details, ref_ids, primary_host, is_active, active_plan, pricing_plans, property_details, check_in_out, instructions) FROM '$$PATH$$/3309.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: bernard
--

COPY public.users (id, email, password, first_name, last_name, phone, address, city, state, country, zip, image_url, rbac, hash, is_active, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.users (id, email, password, first_name, last_name, phone, address, city, state, country, zip, image_url, rbac, hash, is_active, created_at, updated_at, deleted_at) FROM '$$PATH$$/3307.dat';

--
-- Name: calendar_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.calendar_availability_id_seq', 31, true);


--
-- Name: cleaning_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.cleaning_companies_id_seq', 7, true);


--
-- Name: company_availability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.company_availability_id_seq', 31, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.migrations_id_seq', 52, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.properties_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bernard
--

SELECT pg_catalog.setval('public.users_id_seq', 16, true);


--
-- Name: calendar_availability calendar_availability_date_unique; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.calendar_availability
    ADD CONSTRAINT calendar_availability_date_unique UNIQUE (date);


--
-- Name: calendar_availability calendar_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.calendar_availability
    ADD CONSTRAINT calendar_availability_pkey PRIMARY KEY (id);


--
-- Name: cleaner_availability cleaner_availability_cleaner_id_calendar_date_id_company_availa; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaner_availability
    ADD CONSTRAINT cleaner_availability_cleaner_id_calendar_date_id_company_availa UNIQUE (cleaner_id, calendar_date_id, company_availability_id);


--
-- Name: cleaning_companies cleaning_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaning_companies
    ADD CONSTRAINT cleaning_companies_pkey PRIMARY KEY (id);


--
-- Name: company_availability company_availability_company_id_calendar_date_id_unique; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.company_availability
    ADD CONSTRAINT company_availability_company_id_calendar_date_id_unique UNIQUE (company_id, calendar_date_id);


--
-- Name: company_availability company_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.company_availability
    ADD CONSTRAINT company_availability_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: cleaner_availability_calendar_date_id_index; Type: INDEX; Schema: public; Owner: bernard
--

CREATE INDEX cleaner_availability_calendar_date_id_index ON public.cleaner_availability USING btree (calendar_date_id);


--
-- Name: cleaner_availability_cleaner_id_index; Type: INDEX; Schema: public; Owner: bernard
--

CREATE INDEX cleaner_availability_cleaner_id_index ON public.cleaner_availability USING btree (cleaner_id);


--
-- Name: cleaner_availability_company_availability_id_index; Type: INDEX; Schema: public; Owner: bernard
--

CREATE INDEX cleaner_availability_company_availability_id_index ON public.cleaner_availability USING btree (company_availability_id);


--
-- Name: company_availability_calendar_date_id_index; Type: INDEX; Schema: public; Owner: bernard
--

CREATE INDEX company_availability_calendar_date_id_index ON public.company_availability USING btree (calendar_date_id);


--
-- Name: company_availability_company_id_index; Type: INDEX; Schema: public; Owner: bernard
--

CREATE INDEX company_availability_company_id_index ON public.company_availability USING btree (company_id);


--
-- Name: cleaner_availability cleaner_availability_calendar_date_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaner_availability
    ADD CONSTRAINT cleaner_availability_calendar_date_id_foreign FOREIGN KEY (calendar_date_id) REFERENCES public.calendar_availability(id) ON DELETE CASCADE;


--
-- Name: cleaner_availability cleaner_availability_cleaner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaner_availability
    ADD CONSTRAINT cleaner_availability_cleaner_id_foreign FOREIGN KEY (cleaner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: cleaner_availability cleaner_availability_company_availability_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.cleaner_availability
    ADD CONSTRAINT cleaner_availability_company_availability_id_foreign FOREIGN KEY (company_availability_id) REFERENCES public.company_availability(id) ON DELETE CASCADE;


--
-- Name: company_availability company_availability_calendar_date_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.company_availability
    ADD CONSTRAINT company_availability_calendar_date_id_foreign FOREIGN KEY (calendar_date_id) REFERENCES public.calendar_availability(id) ON DELETE CASCADE;


--
-- Name: company_availability company_availability_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.company_availability
    ADD CONSTRAINT company_availability_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.cleaning_companies(id) ON DELETE CASCADE;


--
-- Name: join_cleaning_companies_cleaners join_cleaning_companies_cleaners_cleaner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.join_cleaning_companies_cleaners
    ADD CONSTRAINT join_cleaning_companies_cleaners_cleaner_id_foreign FOREIGN KEY (cleaner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: join_cleaning_companies_cleaners join_cleaning_companies_cleaners_cleaning_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.join_cleaning_companies_cleaners
    ADD CONSTRAINT join_cleaning_companies_cleaners_cleaning_company_id_foreign FOREIGN KEY (cleaning_company_id) REFERENCES public.cleaning_companies(id) ON DELETE CASCADE;


--
-- Name: join_host_properties join_host_properties_host_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.join_host_properties
    ADD CONSTRAINT join_host_properties_host_id_foreign FOREIGN KEY (host_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: join_host_properties join_host_properties_property_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: bernard
--

ALTER TABLE ONLY public.join_host_properties
    ADD CONSTRAINT join_host_properties_property_id_foreign FOREIGN KEY (property_id) REFERENCES public.properties(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

